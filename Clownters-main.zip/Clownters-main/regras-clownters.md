# Organização Clownters 🇮🇲

Olá, seja bem vindo a organização Clownters, em nossa comunidade existem várias regras, obrigações e proibições para manter o bom funcionamento e uma interação saudável entre os participantes, confira logo abaixo.

## Regras, obrigações e proibições, globais

Em nossa organização nós preservarmos pela liberdade de expressão mas temos algunas proibição, elas foram impostas por escolha da comunidade e outras pela administração, caso não esteja de acordo com as regras você será convidado a se retirar!

### Proibições

- Pornografia e incitação sexual
  - Qualquer conteúdo que contenha pornografia ou incite a esse tipo de assunto

- Instigação ao Nazismo
  - Esse veto está aqui porque ocorre com frequência em grupos fechados

- homofobia, xenofobia
  - Pessoas que preguem isso será removido(a)
  - Independente da sua origem ou raça você será bem vindo(a) a nossa comunidade

- Disseminação de redes sociais
  - Proibido a divulgação dessas redes, Facebook, Instagram, WhatsApp, YouTube, Twitter, TikTok, Kawai... 
  - Porque são plataforma que não se preocupem com bem estar dos seus clientes

### Obrigações

- Possuir conhecimentos de informática básica 
  - Conhecer seu dispositivo
  - Sabe manusear o básico do seu software e hardware
  - Ter uma noção dos programas básico do seu sistema
  - resumindo saber como usar seu celular ou computador

-  Ter um contato regular com a comunidade
   - Está ativos em média um dia por semana compartilhando aprendizagens ou interagindo

### Regras
 - Não se deve faz divulgações nos grupos
 - Evitar o compartilhamento de links
 - Possuir a responsabilidade de não usar palavras de baixo calão
 - Esquivar-se de brigas entre membros
 - Ter mais de 15 anos
